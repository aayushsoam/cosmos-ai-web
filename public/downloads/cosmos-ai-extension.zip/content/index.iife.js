(function(){"use strict";let e=null,n=null;function r(){console.log("[NanoBrowser] showGlowingBorder called");try{if(e){console.log("[NanoBrowser] Border already showing");return}if(!document.body){console.warn("[NanoBrowser] Document body not available, retrying..."),setTimeout(r,100);return}if(n=document.createElement("div"),n.id="nano-browser-outer-glow",Object.assign(n.style,{position:"fixed",top:"-10px",left:"-10px",right:"-10px",bottom:"-10px",pointerEvents:"none",zIndex:"2147483646",borderRadius:"0px",boxShadow:"0 0 60px rgba(59, 130, 246, 0.9), 0 0 100px rgba(59, 130, 246, 0.6)",animation:"nano-outer-glow 3s ease-in-out infinite"}),e=document.createElement("div"),e.id="nano-browser-glow",Object.assign(e.style,{position:"fixed",top:"0",left:"0",right:"0",bottom:"0",pointerEvents:"none",zIndex:"2147483647",border:"3px solid rgba(59, 130, 246, 0.8)",borderRadius:"0px",boxShadow:"inset 0 0 30px rgba(59, 130, 246, 0.8), inset 0 0 60px rgba(59, 130, 246, 0.5), 0 0 30px rgba(59, 130, 246, 0.8)",animation:"nano-glow-pulse 2s ease-in-out infinite"}),!document.getElementById("nano-glow-animation")){const o=document.createElement("style");o.id="nano-glow-animation",o.textContent=`
        @keyframes nano-glow-pulse {
          0%, 100% {
            box-shadow: inset 0 0 20px rgba(59, 130, 246, 0.6), inset 0 0 40px rgba(59, 130, 246, 0.3), 0 0 20px rgba(59, 130, 246, 0.6);
            border-color: rgba(59, 130, 246, 0.6);
          }
          50% {
            box-shadow: inset 0 0 40px rgba(59, 130, 246, 1), inset 0 0 80px rgba(59, 130, 246, 0.6), 0 0 40px rgba(59, 130, 246, 1);
            border-color: rgba(59, 130, 246, 1);
          }
        }
        
        @keyframes nano-outer-glow {
          0%, 100% {
            box-shadow: 0 0 40px rgba(59, 130, 246, 0.6), 0 0 80px rgba(59, 130, 246, 0.3);
          }
          50% {
            box-shadow: 0 0 80px rgba(59, 130, 246, 0.9), 0 0 120px rgba(59, 130, 246, 0.6);
          }
        }
        
        /* Ensure the border is always on top */
        #nano-browser-outer-glow, #nano-browser-glow {
          position: fixed !important;
          pointer-events: none !important;
          z-index: 2147483647 !important; /* Max z-index */
        }
      `,document.head.appendChild(o),console.log("[NanoBrowser] Added glow animation styles")}document.body.appendChild(n),document.body.appendChild(e),console.log("[NanoBrowser] Glowing border elements added to DOM")}catch(o){console.error("[NanoBrowser] Error showing glowing border:",o)}}function a(){e&&(e.remove(),e=null),n&&(n.remove(),n=null),console.log("[NanoBrowser] Glowing border elements removed from DOM")}function t(){console.log("[NanoBrowser] Showing glowing border"),document.readyState==="loading"?document.addEventListener("DOMContentLoaded",()=>{console.log("[NanoBrowser] DOM loaded, showing border"),r()}):(console.log("[NanoBrowser] DOM already loaded, showing border immediately"),r())}function s(){console.log("[NanoBrowser] Hiding glowing border"),a()}chrome.runtime.onMessage.addListener((o,l,d)=>{console.log("[NanoBrowser] Received message:",o);try{o.type==="task_start"?t():o.type==="task_end"&&s()}catch(i){console.error("[NanoBrowser] Error in message handler:",i)}return!0}),chrome.runtime.sendMessage({type:"check_task_status"},o=>{if(chrome.runtime.lastError){console.warn("[NanoBrowser] Could not check task status:",chrome.runtime.lastError);return}o&&o.isTaskRunning&&(console.log("[NanoBrowser] Task is already running, showing border"),t())}),console.log("content script loaded with glowing border")})();
